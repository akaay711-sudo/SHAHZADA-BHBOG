SHAHZADA BUG BOT

A Telegram bot with WhatsApp multi-session support, role-based access control, pairing flows, sub-bot deployment, and persistent JSON storage.

Developer: MR SHAHZADA

Version: 1.0.0

Platform: Telegram + WhatsApp

Language: URDU

Overview

SHAHZADA BUG BOT is a modular Telegram and WhatsApp management project built with:

- Grammy for Telegram bot handling
- Baileys-based WhatsApp session management
- JSON-based persistent storage
- Modular bot runtime
- Independent sub-bot deployment
- Role-based user access management

Branding

- Bot Name: SHAHZADA BUG BOT
- Short Name: SHAHZADA
- Creator: SHAHZADA
- Tagline: Advanced Telegram & WhatsApp Management
- Version: 1.0.0

All branding settings are centralized in "src/config/config.js".

Installation

npm install

Configure your ".env" file:

BOT_TOKEN=your_telegram_bot_token
OWNER_ID=your_telegram_user_id
OWNER_USERNAME=@your_username
MENU_MEDIA_TYPE=photo
MENU_PHOTO_URL=https://example.com/menu-photo.jpg
MENU_VIDEO_URL=https://example.com/menu-video.mp4
FORCE_JOIN_CHANNEL=

Start the bot:

npm start

Developer

SHAHZADA 

Project: SHAHZADA BUG BOT